package com.example.tamto_q_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
