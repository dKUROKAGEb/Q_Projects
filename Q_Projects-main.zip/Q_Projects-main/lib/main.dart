import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tamto_q_project/Test/database_helper.dart';
import 'package:tamto_q_project/app/modules/home/views/home_view.dart';
import 'app/routes/app_pages.dart';
import 'app/modules/home/controllers/home_controller.dart';
import 'package:flutter_tts/flutter_tts.dart';

void main() async {
  // Step 2

  // await GetStorage.init();
  WidgetsFlutterBinding.ensureInitialized();
  // Step 3
  // final keyString = GetStorage();

// text to speech setting

  RawKeyboard.instance.addListener((event) async {
    if (event is RawKeyDownEvent) {
      // print('$event');
      String key = event.physicalKey.toString();
      //แปลงค่า key board เป็น String
      key = key.substring(64);

      print('${key}');
      if (key == '"Digit 0")') {
        // print('1');
        Get.put(HomeController()).addQueue();
        // Get.put(HomeController()).increment();
      }
      if (key == '"Key C")') {
        // print('2');
        Get.put(HomeController()).deleteQueue();
      }
      // if (key == '"Digit 1")' || key == '"Digit 2")' || key == '"Digit 3")') {
      //   print('2');
      //   Get.put(HomeController()).updateQueue(key);
      // }
      if (key == '"Key S")') {
        // print('2');
        Get.put(HomeController()).latestQueue();
      }
      if (key == '"Equal")') {
        // print('3');
        Get.put(HomeController()).dataLoad();
      }
      if (key == '"Key W")') {
        // print('3');
        Get.put(HomeController()).query1row();
      }

      if (key == '"Digit 1")' || key == '"Digit 2")' || key == '"Digit 3")') {
        // print('3');
        Get.put(HomeController()).table(key);
        // await flutterTts.speak('ขอเชิญหมายเลข ');
        // await flutterTts.speak("12");
      }
      // if (key == '"Digit 2")') {
      //   // print('3');
      //   Get.put(HomeController()).table2();
      //   // await flutterTts.speak("สวัสดีครับ");
      // }
      // if (key == '"Digit 3")') {
      //   // print('3');
      //   Get.put(HomeController()).table3();
      //   // await flutterTts.speak("สวัสดีครับ");
      // }
      if (key == '"Backspace")') {
        // print('3');
        Get.put(HomeController()).deleteAll();
      }
    }
  });

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]).then((value) => runApp(
        GetMaterialApp(
          title: "Q Project",
          initialRoute: AppPages.INITIAL,
          getPages: AppPages.routes,
          debugShowCheckedModeBanner: false,
        ),
      ));
}
