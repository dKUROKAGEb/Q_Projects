import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:flutter/foundation.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import '../../../../Test/database_helper.dart';
import 'package:flutter_tts/flutter_tts.dart';

final dbHelper = DatabaseHelper();

class HomeController extends GetxController {
  //TODO: Implement HomeController
  final count = 0.obs;
  final tableService = 0.obs;
  final callQueue = true.obs;
  var queue = 0.obs;
  RxList<int> queues = <int>[].obs;
  String _message = '';
  final KeyString = GetStorage();
  var QT = ''.obs;
  var QT1 = ''.obs;
  var QT2 = ''.obs;
  var QT3 = ''.obs;

  RxString thaiDate = ''.obs;
  final urlImages = [
    'https://images.unsplash.com/photo-1520342868574-5fa3804e551c?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=6ff92caffcdd63681a35134a6770ed3b&auto=format&fit=crop&w=1951&q=80',
    'https://images.unsplash.com/photo-1522205408450-add114ad53fe?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=368f45b0888aeb0b7b08e3a1084d3ede&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=94a1e718d89ca60a6337a6008341ca50&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1523205771623-e0faa4d2813d?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=89719a0d55dd05e2deae4120227e6efc&auto=format&fit=crop&w=1953&q=80',
    'https://images.unsplash.com/photo-1508704019882-f9cf40e475b4?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=8c6e5e3aba713b17aa1fe71ab4f0ae5b&auto=format&fit=crop&w=1352&q=80',
    'https://images.unsplash.com/photo-1519985176271-adb1088fa94c?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=a0c8d632e977f94e5d312d9893258f59&auto=format&fit=crop&w=1355&q=80'
  ].obs;
//image slide

  @override
  void onInit() async {
    super.onInit();
    initializeDateFormatting('th', null);
    updateThaiDate();
  }

  void updateThaiDate() {
    DateTime now = DateTime.now();
    var formatter = DateFormat.yMMMMEEEEd('th');
    thaiDate.value = formatter.format(now);
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    RawKeyboard.instance.removeListener;
    super.onClose();
  }

  void increment() {
    tableService.value++;
    update();
  }

  void decrement() => tableService.value--;

  Future<void> addQueue() async {
    await dbHelper.init();
    final latestQueue = await dbHelper.latestQueue();
    //get last value of queue
    // debugPrint('query rows:');
    // debugPrint(latestQueue.toString());

    queue.value = latestQueue + 1;
    queues.add(queue.value);
    print('User Input: $queues');
    Map<String, dynamic> row = {
      DatabaseHelper.que_date: DateFormat('dd-MM-yyyy').format(DateTime.now()),
      DatabaseHelper.que_number: queue.value,
      DatabaseHelper.service_table: 0,
      DatabaseHelper.que_status: 'WAIT'
    };
    //set value for insert
    final id = await dbHelper.insert(row);
    // debugPrint('inserted row id: $id');
    // update();
    dataLoad();
  }

  Future<void> dataLoad() async {
    await dbHelper.init();
    final allRows = await dbHelper.queryAllRows();
    queues.clear();
    allRows.forEach((map) {
      if (map['service_table'] == 0) {
        queues.add(map['number']);
      } //set queue data to array
    });
  }

  Future<void> updateQueue(int table) async {
    await dbHelper.init();
    // queue.value = latestQueue();
    final firstRow = await dbHelper.queryActive(table);
    //check first active queue
    var id = firstRow.map((e) => e['id']);
    var number = firstRow.map((e) => e['id']);
    String tid = id.toString();
    tid = tid.substring(1, tid.length - 1);
    String tnumber = number.toString();
    tnumber = tnumber.substring(1, tnumber.length - 1);

    Map<String, dynamic> row = {
      DatabaseHelper.Id: tid,
      DatabaseHelper.que_date: DateFormat('dd-MM-yyyy').format(DateTime.now()),
      DatabaseHelper.que_number: tnumber,
      DatabaseHelper.service_table: tableService.value,
      DatabaseHelper.que_status: 'SUCCESS'
    }; //change status to success

    // update row in the database
    final rowsAffected = await dbHelper.update(row);
    // debugPrint('updated $rowsAffected row(s)');
    dataLoad();
  }

  Future<void> table(String key) async {
    // fetch first row to update
    await dbHelper.init();

    if (key == '"Digit 1")') {
      tableService.value = 1;
    } else if (key == '"Digit 2")') {
      tableService.value = 2;
    } else if (key == '"Digit 3")') {
      tableService.value = 3;
    }

    if (QT.value != '') {
      updateQueue(tableService.value);
    }
    final firstRow = await dbHelper.queryFirstRow();
    //check first waiting row
    var id = firstRow.map((e) => e['id']);
    var number = firstRow.map((e) => e['id']);
    String tid = id.toString();
    tid = tid.substring(1, tid.length - 1);
    String tnumber = number.toString();
    tnumber = tnumber.substring(1, tnumber.length - 1);
    QT.value = tnumber;
    if (tableService.value == 1) {
      QT1.value = tnumber;
    } else if (tableService.value == 2) {
      QT2.value = tnumber;
    } else if (tableService.value == 3) {
      QT3.value = tnumber;
    }
//set value to edit status
    Map<String, dynamic> row = {
      DatabaseHelper.Id: tid,
      DatabaseHelper.que_date: DateFormat('dd-MM-yyyy').format(DateTime.now()),
      DatabaseHelper.que_number: tnumber,
      DatabaseHelper.service_table: tableService.value,
      DatabaseHelper.que_status: 'ACTIVE'
    };

    // update row in the database
    final rowsAffected = await dbHelper.update(row);
    // debugPrint('updated $rowsAffected row(s)');
    dataLoad();
    if (QT.value != '') {
      voice(int.parse(QT.value), tableService.value);
    }
  }

  Future<void> deleteQueue() async {
    if (queues.length != 0) {
      queues.removeAt(0);
    }
    print('User Input: $queues');
    final id = await dbHelper.queryRowCount();
    final rowsDeleted = await dbHelper.delete(id);
    debugPrint('deleted $rowsDeleted row(s): row $id');
    // update();
    dataLoad();
  }

  Future<void> query() async {
    await dbHelper.init();
    final allRows = await dbHelper.queryAllRows();
    //get data of queue
    // debugPrint('latest queue:');
    // for (final row in allRows) {
    //   debugPrint(row.toString());
    // }
    queues.clear();
    allRows.forEach((map) {
      if (map['service_table'] == 0) {
        queues.add(map['number']);
      }
    }); //set data to array
  }

  Future<void> query1row() async {
    await dbHelper.init();
    final firstRow = await dbHelper.queryFirstRow();
    debugPrint('query first row:');
    var txt = firstRow.map((e) => e['status']);
    // String s = txt.toString().substring(1);
    // String s = txt.toString();
    // print(s.substring(1, s.length - 1));
    //for (final row in firstRows) {
    debugPrint(firstRow.toString());
    //}
  }

  Future<void> deletedatabase() async {
    // Assuming that the number of rows is the id for the last row.
    await dbHelper.init();
    final id = await dbHelper.queryRowCount();
    final rowsDeleted = await dbHelper.delete(id);
    debugPrint('deleted $rowsDeleted row(s): row $id');
  }

  Future<void> deleteAll() async {
    await dbHelper.init();

    queues.clear();
    print('User Input: $queues');
    // final id = await dbHelper.queryRowCount();
    final rowsDeleted = await dbHelper.deleteAll();
  }

  Future<int> latestQueue() async {
    await dbHelper.init();
    final row = await dbHelper.latestQueue();
    //check last queue
    // debugPrint('query all rows:');
    // debugPrint(row.toString());
    return row.toInt();
  }

  Future<void> voice(int qt, int ts) async {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterTts flutterTts = FlutterTts();
    flutterTts.setLanguage('th-TH');
    flutterTts.setSpeechRate(0.7);
    flutterTts.setPitch(1.0);
    flutterTts.setVolume(1.0);
//set text to speech
    await flutterTts.speak('ขอเชิญหมายเลข');
    await Future.delayed(Duration(seconds: 1));
    await Future.delayed(Duration(microseconds: 700));
    await flutterTts.speak('$qt');
    await Future.delayed(Duration(seconds: 1));

    await flutterTts.speak('ที่ช่องบริการ ${ts} ค่ะ');
  }
  // void changeStage() {
  //   if (callQueue.value == true) {
  //     callQueue.value = false;
  //   } else {
  //     callQueue.value = true;
  //   }
  // }
}
