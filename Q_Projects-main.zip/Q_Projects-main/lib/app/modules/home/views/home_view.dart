import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/date_symbol_data_local.dart';
import '../controllers/home_controller.dart';
import 'package:intl/intl.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // final KeyString = GetStorage();

    // String? key = Get.arguments;

    return Scaffold(
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      body: Center(
          child: SafeArea(
        child: Center(
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Obx(
                  () => Text(
                    controller.thaiDate.value,
                    // textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        decoration: TextDecoration.none),
                  ),
                ),
              ),
              Expanded(
                flex: 9,
                child: Row(
                  children: [
                    Expanded(
                      flex: 8,
                      child: Obx(
                        () => CarouselSlider.builder(
                          itemCount: controller.urlImages.length,
                          itemBuilder: ((context, index, realIndex) {
                            final urlImage = controller.urlImages[index];
                            return buildImage(urlImage, index);
                          }),
                          options: CarouselOptions(
                              height: 500, autoPlay: true, viewportFraction: 1),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Column(
                        children: [
                          Obx(
                            () => _topMenu(
                              title: 'คิวที่รอรับบริการ ',
                              // title: '${controller.queues.length}',

                              subTitle:
                                  'จำนวนคิวที่รอรับบริการ ${controller.queues.length}',
                              // action: Container(),
                            ),
                          ),
                          // ),
                          const SizedBox(height: 20),
                          Expanded(
                            child: Obx(
                              () => ListView.builder(
                                itemCount: controller.queues.length,
                                itemBuilder: ((context, index) {
                                  final queue =
                                      controller.queues[index].toString();
                                  return _itemOrder(queue, index);
                                }),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Center(
              //   child: Obx(
              //     () => Text(
              //       'HomeView is ${controller.tableService.value < 2 ? "< 2 working" : "working"} ${controller.tableService}',
              //       style: TextStyle(fontSize: 20),
              //     ),
              //   ),
              // ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // _item(
                  //   // image: 'items/1.png',
                  //   title: 'วันที่',
                  //   queue: ' ${controller.date}',
                  //   // item: '11 item',
                  // ),
                  Obx(() {
                    if (controller.QT1.value != '') {
                      return _item(
                        // image: 'items/1.png',
                        title: 'โต๊ะบริการที่ 1',
                        queue: ' ${controller.QT1.value}',
                        // item: '11 item',
                      );
                    } else {
                      return _item(
                        // image: 'items/1.png',
                        title: 'โต๊ะบริการที่ 1',
                        queue: 'ว่าง',
                        // item: '11 item',
                      );
                    }
                  }),
                  Obx(() {
                    if (controller.QT2.value != '') {
                      return _item(
                        // image: 'items/1.png',
                        title: 'โต๊ะบริการที่ 2',
                        queue: ' ${controller.QT2.value}',
                        // item: '11 item',
                      );
                    } else {
                      return _item(
                        // image: 'items/1.png',
                        title: 'โต๊ะบริการที่ 2',
                        queue: 'ว่าง',
                        // item: '11 item',
                      );
                    }
                  }),
                  Obx(() {
                    if (controller.QT3.value != '') {
                      return _item(
                        // image: 'items/1.png',
                        title: 'โต๊ะบริการที่ 3',
                        queue: ' ${controller.QT3.value}',
                        // item: '11 item',
                      );
                    } else {
                      return _item(
                        // image: 'items/1.png',
                        title: 'โต๊ะบริการที่ 3',
                        queue: 'ว่าง',
                        // item: '11 item',
                      );
                    }
                  }),
                  Obx(() {
                    if (controller.queues.length != 0) {
                      return _itemlastqueue(
                        // image: 'items/1.png',
                        title: 'คิวที่เพิ่มล่าสุด',
                        queue: ' ${controller.queues.last}',
                        // item: '11 item',
                      );
                    } else {
                      return _itemlastqueue(
                        // image: 'items/1.png',
                        title: 'คิวที่เพิ่มล่าสุด',
                        queue: 'ไม่มีคิว',
                        // item: '11 item',
                      );
                    }
                  }),
                ],
              ),
            ],
          ),
        ),
      )),
    );
  }

  Widget _item({
    // required String image,
    required String title,
    required String queue,
    // required String item,
  }) =>
      Container(
        margin: const EdgeInsets.only(top: 20, right: 20, bottom: 20),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Color.fromARGB(255, 53, 54, 64),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Container(
            //   height: 130,
            //   decoration: BoxDecoration(
            //     borderRadius: BorderRadius.circular(16),
            //     image: DecorationImage(
            //       image: AssetImage(image),
            //       fit: BoxFit.cover,
            //     ),
            //   ),
            // ),
            // const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  decoration: TextDecoration.none),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  queue,
                  style: const TextStyle(
                      color: Colors.deepOrange,
                      fontSize: 30,
                      decoration: TextDecoration.none),
                ),
                // Text(
                //   item,
                //   style: const TextStyle(
                //     color: Colors.white60,
                //     fontSize: 12,
                //   ),
                // ),
              ],
            ),
          ],
        ),
      );
  Widget _itemlastqueue({
    // required String image,
    required String title,
    required String queue,
    // required String item,
  }) =>
      Container(
        margin: const EdgeInsets.only(top: 20, right: 20, bottom: 20),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Color.fromARGB(255, 53, 54, 64),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Container(
            //   height: 130,
            //   decoration: BoxDecoration(
            //     borderRadius: BorderRadius.circular(16),
            //     image: DecorationImage(
            //       image: AssetImage(image),
            //       fit: BoxFit.cover,
            //     ),
            //   ),
            // ),
            // const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  decoration: TextDecoration.none),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  queue,
                  style: const TextStyle(
                      color: Colors.deepOrange,
                      fontSize: 30,
                      decoration: TextDecoration.none),
                ),
                // Text(
                //   item,
                //   style: const TextStyle(
                //     color: Colors.white60,
                //     fontSize: 12,
                //   ),
                // ),
              ],
            ),
          ],
        ),
      );
  Widget buildImage(String urlImage, int index) => Container(
        margin: EdgeInsets.symmetric(horizontal: 10),
        color: Colors.grey,
        child: Image.network(
          urlImage,
          fit: BoxFit.cover,
        ),
      );

  Widget _topMenu({
    required String title,
    required String subTitle,
    // required Widget action,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                title,
                style: const TextStyle(
                    color: Color.fromARGB(255, 255, 255, 255),
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    decoration: TextDecoration.none),
              ),
            ),
            // const SizedBox(height: 6),
            Text(
              subTitle,
              style: const TextStyle(
                  color: Color.fromARGB(255, 255, 255, 255),
                  fontSize: 15,
                  decoration: TextDecoration.none),
            ),
          ],
        ),
        Expanded(flex: 1, child: Container(width: double.infinity)),
        // Expanded(flex: 5, child: action),
      ],
    );
  }

  Widget _itemOrder(String queue, int index) => Container(
        padding: const EdgeInsets.all(8),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Color.fromARGB(255, 61, 62, 70),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    queue = controller.queues[index].toString(),
                    // textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 50,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        decoration: TextDecoration.none),
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
          ],
        ),
      );
}
