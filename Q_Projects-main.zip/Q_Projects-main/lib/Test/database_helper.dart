import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseHelper {
  static const _databaseName = "MyDatabase.db";
  static const _databaseVersion = 1;

  static const table = 'Queues';

  static const Id = 'id';
  static const que_date = 'date';
  static const que_number = 'number';
  static const service_table = 'service_table';
  static const que_status = 'status';

  late Database _db;

  DatabaseHelper() {
    init().then((db) {
      _db = db;
    });
  }

  // this opens the database (and creates it if it doesn't exist)
  Future<Database> init() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  // SQL code to create the database table
  Future _onCreate(Database db, int version) async {
    await db.execute('''
          CREATE TABLE $table (
            $Id INTEGER PRIMARY KEY,
            $que_date DATE NOT NULL,
            $que_number INTEGER NOT NULL,
            $service_table INTEGER NOT NULL,
            $que_status TEXT NOT NULL
          )
          ''');
  }

  // Helper methods

  // Inserts a row in the database where each key in the Map is a column name
  // and the value is the column value. The return value is the id of the
  // inserted row.
  Future<int> insert(Map<String, dynamic> row) async {
    if (_db == null) {
      throw Exception("Database has not been initialized yet.");
    }
    print('insert called with row: $row');
    int result = await _db.insert(table, row);
    print('insert returned result: $result');
    return result;
  }

  // All of the rows are returned as a list of maps, where each map is
  // a key-value list of columns.
  Future<List<Map<String, dynamic>>> queryAllRows() async {
    final results = await _db.rawQuery('SELECT * FROM $table');
    return results;
  }

  // All of the methods (insert, query, update, delete) can also be done using
  // raw SQL commands. This method uses a raw query to give the row count.
  Future<int> queryRowCount() async {
    final results = await _db.rawQuery('SELECT COUNT(*) FROM $table');
    return Sqflite.firstIntValue(results) ?? 0;
  }

  //
  Future<List<Map<String, dynamic>>> queryFirstRow() async {
    return await _db.query(table,
        where: 'service_table = ? AND status = ?',
        whereArgs: [0, 'WAIT'],
        limit: 1);
  }

  Future<List<Map<String, dynamic>>> queryActive(int serviceTable) async {
    return await _db.query(table,
        where: 'service_table = ? AND status = ?',
        whereArgs: [serviceTable, 'ACTIVE'],
        limit: 1);
  }
  // Future<int> queryFirstRow() async {
  //   final results = await _db.rawQuery(
  //       'SELECT COUNT(*) FROM $table service_table = 0 AND status = WAIT ORDER BY id ASC LIMIT 1');
  //   return Sqflite.firstIntValue(results) ?? 0;
  // }

  Future<int> latestQueue() async {
    final results = await _db
        .rawQuery('SELECT COUNT(*) FROM $table ORDER BY id DESC LIMIT 1');
    return Sqflite.firstIntValue(results) ?? 0;
  }

  // We are assuming here that the id column in the map is set. The other
  // column values will be used to update the row.
  Future<int> update(Map<String, dynamic> row) async {
    Map<String, dynamic> updatedValues = {
      'date': row['date'],
      'number': row['number'],
      'service_table': row['service_table'],
      'status': row['status']
    };
    return await _db.update(
      table,
      updatedValues,
      where: 'id = ?',
      whereArgs: [row['id']],
    );
  }

  Future<int> updateTable1() async {
    return await _db.update(
      table,
      {'service_table': '1', 'status': 'active'},
      where: 'service_table = ? AND status = ? LIMIT 1',
      whereArgs: [0, 'WAIT'],
    );
  }
  // Deletes the row specified by the id. The number of affected rows is
  // returned. This should be 1 as long as the row exists.

  // Deletes the row specified by the id. The number of affected rows is
  // returned. This should be 1 as long as the row exists.
  Future<int> delete(int id) async {
    return await _db.delete(
      table,
      where: '$Id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteAll() async {
    final results = await _db.rawQuery('delete FROM $table');
    return Sqflite.firstIntValue(results) ?? 0;
  } //delete all data
}
